
def filla(b):
        for i in range(0,10):
                b[i] = i


a = [0]*10
filla(a)

a = [0,16,31,45]

def test():
    myfunc()



def myfunc():
    print("hello")

test()
