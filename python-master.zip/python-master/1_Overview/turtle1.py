import turtle

turtle.goto(100,100)


 